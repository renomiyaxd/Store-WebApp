<!DOCTYPE html>
<html>

<head>
<style>
body {
    background-color: lightblue;
}

p{
    font-family: Arial, Helvetica, sans-serif;
}
h2{
    font-family: Arial, Helvetica, sans-serif;
}

h1{
    font-family: Arial, Helvetica, sans-serif;
}

</style>
</head>

<body>

<h1>Welcome to the login page</h1>

<form action="login_process.php" method="post" align="center">

<h2> Enter username</h2>
<Input type="text" name="number_1" size=20>
<h2> Enter password</h2>
<Input type="password" name="number_2" size=20>
<Input type="Submit" value="Login">

</form>
<h2>
</html>
